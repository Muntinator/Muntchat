# Contributing to CalcGPT 3

Contributions are welcome, especially changes that can be measured on a real
TI-Nspire CX II instead of only improving desktop training loss.

## Before changing code

1. Preserve the current E40 checkpoint and ready-to-run TNS.
2. Create a new checkpoint format number for incompatible architecture changes.
3. Keep calculator runtime code compatible with TI Python, not merely CPython.
4. Do not add canned conversational responses and describe them as understanding.
5. Do not claim classifier confidence is response accuracy.

## Useful contribution areas

- Held-out relevance evaluation and regression tests
- Teacher-student distillation focused on response relevance
- A compact learned candidate ranker
- Better repetition and incomplete-sentence detection
- Conversation-state conditioning
- Subword or byte tokenization experiments
- Faster matrix operations and lower-memory loading
- Smaller export encoding and installer improvements
- UI, keyboard, scrolling, and paste bug fixes
- TI-Nspire OS and hardware compatibility testing

## Testing expectations

Record:

- Commit/version and checkpoint epoch
- TI-Nspire model and OS version
- Physical calculator or official preview
- Launch, first-load, and response timing
- Training and validation loss
- The complete standardized prompt suite
- Every output, including failures
- Peak document size and any MemoryError

Do not select only successful conversations. Compare the new version with the
included E40 model using the same prompts and random-seed policy.

## Bug reports

Copy `BUG_REPORT_TEMPLATE.txt` into your report and fill in every applicable
field. Include the entire traceback as plain text when possible.

## Pull requests or release forks

Keep generated artifacts separate from source. Do not commit `.venv`, downloaded
corpora, `.DS_Store`, `__MACOSX`, `__pycache__`, or every epoch snapshot. Include
only the active checkpoint when a trained model is necessary for reproduction.

Code contributions are accepted under the MIT License. Do not add datasets or
weights whose licenses are incompatible with the existing noncommercial release.

