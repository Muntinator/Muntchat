CalcGPT 3 - Experimental Offline Neural Language Model for TI-Nspire CX II
Version 1.0 (E40 research release)
Author and primary tester: Fred Bennett

OVERVIEW
========

CalcGPT 3 is an experimental word-level neural language model that runs entirely
inside standard TI-Nspire Python. It does not use Ndless, internet access, an API,
or calculator-side third-party libraries. The model is trained on a Mac, exported
with signed 8-bit weights, stored in a TI-Nspire problem, and evaluated by a custom
GRU inference engine written in Python.

This release is intended as a research and development starting point. It proves
that a genuine quantized neural text generator can run on a stock TI-Nspire CX II,
but it does NOT provide reliable language understanding. Typical failures include
repeated high-frequency phrases, weak prompt relevance, contradictions, incomplete
grammar, and confident-sounding nonsense. The header percentage is classifier
separation confidence, not answer accuracy.

TESTED PERFORMANCE
==================

Hardware/software: TI-Nspire CX II using standard TI Python
Document size: approximately 183 KB
Ctrl+R to interface: approximately 40 seconds
First model load: approximately 30 seconds
Typical generated response: approximately 20 seconds
Later responses avoid the model-loading step until the app is exited.

MODEL
=====

- Architecture: single-layer word-level GRU
- Vocabulary: 640 tokens
- Embedding width: 20
- Hidden width: 30
- Training corpus: DailyDialog
- Training release: 40 epochs
- Quantization: signed 8-bit weights
- Output: two sampled candidates with relevance/grammar ranking
- Conditioning: dialogue act, emotion, capitalization, repeated punctuation,
  hesitation signals, unigram associations, and ordered bigram associations
- Calculator inference: dependency-free TI Python

QUICK START
===========

1. Transfer ready_to_run/CalcGPT3.tns with TI-Nspire CX Student Software.
2. Open the document on a TI-Nspire CX II.
3. Open the tinylm Python page and press Ctrl+R.
4. Wait for the interface. The first response in each run loads the model.

The ready-to-run document already contains the calculator programs and installed
model variables. Users do not need PyTorch or the Mac trainer merely to run it.

CONTROLS
========

- Enter: send a message, including an empty message
- Up/Down: scroll by line
- Left/Right: scroll by page
- Shift: change the next letter's case
- Caps: toggle uppercase input where supported
- Var: enter a question mark
- Trig: enter an exclamation mark
- Tab: show the calculator-safe paste instructions
- Menu: make the latest response available in the Shell after exit
- Esc: exit

TRAIN OR RESUME ON macOS
========================

Requirements:

- macOS on Apple Silicon or Intel
- Python 3
- Internet access on the first run to download dependencies and DailyDialog
- Approximately 1 GB free while installing PyTorch and its environment

The included source/checkpoints/calcgpt3.pt is the E40 checkpoint. It allows
developers to resume training without repeating the first 40 epochs.

Open Terminal and run:

  cd path/to/CalcGPT3_Experimental_v1.0/source
  python3 install_train_calc.py
  source ~/.zshrc
  train_calc

Enter the number of ADDITIONAL epochs. Training saves the active checkpoint at:

  source/checkpoints/calcgpt3.pt

It also exports calculator programs under:

  source/calculator/

The updated exporter divides newly generated model data into paste-safe programs
named tinydata.py, tinydata2.py, and so on. If manually installing an exported
model, create all programs in the same TI problem and run the tinydata programs
in numerical order. The last part verifies the previous parts before activating
the model.

To train without installing the convenience command:

  cd path/to/CalcGPT3_Experimental_v1.0/source
  python3 -m venv .venv
  source .venv/bin/activate
  python3 -m pip install -r requirements.txt
  python3 train_mac.py --epochs 5

Do not use --reset unless you intentionally want to discard the E40 checkpoint.
Do not publish .venv, cached datasets, __pycache__, or every history checkpoint.

EXPORT WITHOUT MORE TRAINING
============================

With the environment active:

  cd path/to/CalcGPT3_Experimental_v1.0/source
  python3 export_calculator.py

Transfer tinylm.py and every newly generated tinydata*.py file. Future exporters
remove obsolete generated data parts before writing a new matched set.

SOURCE LAYOUT
=============

ready_to_run/CalcGPT3.tns
  Ready-to-run TI-Nspire problem containing the E40 model.

source/train_mac.py
  Downloads and parses DailyDialog, trains/resumes the GRU, learns conditioning
  evidence, saves checkpoints, and invokes the exporter.

source/export_calculator.py
  Quantizes the checkpoint and creates paste-safe calculator programs.

source/calculator_template.py
  TI-Nspire interface, model loader, classifiers, decoder, candidate ranking,
  scrolling, input, and rendering code.

source/calculator/
  Calculator Python generated from the E40 checkpoint. The included tinydata.py
  is the original single-file E40 export used to build the supplied TNS document.
  Re-exporting with the updated exporter creates numbered paste-safe data parts.

source/checkpoints/calcgpt3.pt
  Resumable E40 PyTorch checkpoint.

screenshots/
  Release screenshots showing the interface and representative output. They are
  intentionally not selected to hide the model's current response limitations.

KNOWN LIMITATIONS
=================

See KNOWN_ISSUES.txt. Most importantly, lower training loss does not establish
semantic understanding. At E40, the model often produces fluent fragments that
are unrelated to the prompt. Additional epochs alone are unlikely to fix this.

CONTRIBUTING
============

Bug fixes and experimental improvements are welcome. Read CONTRIBUTING.md and
IMPROVEMENT_ROADMAP.txt before changing the model format. Please report the exact
calculator model/OS, program version, reproduction steps, prompt, output, timing,
and traceback when applicable.

LICENSES AND ATTRIBUTION
========================

Original project code is released under the MIT License; see LICENSE_CODE.txt.
The checkpoint was trained using DailyDialog. See MODEL_LICENSE_AND_ATTRIBUTION.txt
for dataset attribution and noncommercial/share-alike terms.

This project is not affiliated with Texas Instruments, OpenAI, or the DailyDialog
authors. "GPT" in the experimental project name is descriptive branding; this is
a GRU language model, not an OpenAI GPT model.

CREDITS
=======

Project concept, testing, and release: Fred Bennett
AI-assisted code development and documentation: OpenAI ChatGPT
Training corpus: DailyDialog, by Yanran Li and collaborators
