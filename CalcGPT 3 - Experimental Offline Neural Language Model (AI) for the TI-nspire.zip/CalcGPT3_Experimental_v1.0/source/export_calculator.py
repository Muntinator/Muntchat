#!/usr/bin/env python3
"""Quantize a Mac checkpoint and embed it in calculator/tinylm.py."""
from pathlib import Path
import base64
import zlib
import torch

ROOT = Path(__file__).resolve().parent


def quantize(tensor):
    values = tensor.detach().cpu().flatten().float()
    maximum = max(float(values.abs().max()), 1e-8)
    scale = maximum / 127.0
    ints = torch.clamp(torch.round(values / scale), -127, 127).to(torch.int16).tolist()
    raw = bytes(value & 255 for value in ints)
    length = len(raw)
    raw += bytes((-length) % 4)
    encoded = base64.b85encode(raw).decode("ascii")
    return scale, length, encoded


def export(checkpoint=ROOT / "checkpoints" / "calcgpt3.pt"):
    saved = torch.load(checkpoint, map_location="cpu", weights_only=False)
    state, vocab, cfg = saved["model"], saved["vocab"], saved["config"]
    tensors = ["embed.weight", "gru.weight_ih_l0", "gru.weight_hh_l0",
               "gru.bias_ih_l0", "gru.bias_hh_l0", "output.weight", "output.bias"]
    scales, lengths, blobs = [], [], []
    for name in tensors:
        scale, length, blob = quantize(state[name])
        scales.append(scale); lengths.append(length); blobs.append(blob)
    template = (ROOT / "calculator_template.py").read_text()
    assoc_raw = bytearray()
    for prompt, choices in sorted(saved.get("associations", {}).items()):
        choices = choices[:3]
        assoc_raw.extend(((prompt >> 8) & 255, prompt & 255, len(choices)))
        for token, weight in choices:
            assoc_raw.extend(((token >> 8) & 255, token & 255,
                              max(0, min(255, round(weight / 1.8 * 255)))))
    assoc_length = len(assoc_raw)
    assoc_raw.extend(bytes((-assoc_length) % 4))
    assoc_blob = base64.b85encode(bytes(assoc_raw)).decode("ascii")
    intent_raw=bytearray(saved.get("intent_priors",[64,64,64,63]))
    intent_items=[]
    for token,weights in saved.get("intent_model",{}).items():
        ordered=sorted(weights,reverse=True)
        intent_items.append((ordered[0]-ordered[1],token,weights))
    intent_items.sort(reverse=True)
    for _,token,weights in intent_items[:128]:
        intent_raw.extend(((token>>8)&255,token&255))
        intent_raw.extend(max(0,min(255,int(value))) for value in weights)
    emotion_raw=bytearray(saved.get("emotion_priors",[220,6,2,3,14,7,3]))
    emotion_items=[]
    for token,weights in saved.get("emotion_model",{}).items():
        ordered=sorted(weights,reverse=True)
        emotion_items.append((ordered[0]-ordered[1],token,weights))
    emotion_items.sort(reverse=True)
    for _,token,weights in emotion_items[:128]:
        emotion_raw.extend(((token>>8)&255,token&255))
        emotion_raw.extend(max(0,min(255,int(value))) for value in weights)
    model_id = zlib.crc32(("".join(blobs)+assoc_blob).encode("ascii")+bytes(intent_raw)+bytes(emotion_raw)) & 0x7fffffff
    # Build independently pasteable storage units. A unit writes at most one
    # 800-number TI list; no installer ever constructs the whole model.
    units=[]; qparts=[]
    for tensor,(blob,length) in enumerate(zip(blobs,lengths)):
        raw=base64.b85decode(blob.encode("ascii"))[:length]
        count=0
        for start in range(0,len(raw),1600):
            chunk=raw[start:start+1600]
            padded=chunk+bytes((-len(chunk))%4)
            units.append(("tdq"+str(tensor)+"x"+str(count),len(chunk),1,
                          base64.b85encode(padded).decode("ascii")))
            count+=1
        qparts.append(count)
    chars=bytearray()
    for word in vocab:
        chars.extend(word.encode("ascii")); chars.append(0)
    vparts=0
    for start in range(0,len(chars),800):
        chunk=bytes(chars[start:start+800]); padded=chunk+bytes((-len(chunk))%4)
        units.append(("tdvc"+str(vparts),len(chunk),0,
                      base64.b85encode(padded).decode("ascii"))); vparts+=1
    aparts=0
    assoc_bytes=bytes(assoc_raw[:assoc_length])
    for start in range(0,len(assoc_bytes),800):
        chunk=assoc_bytes[start:start+800]; padded=chunk+bytes((-len(chunk))%4)
        units.append(("tda"+str(aparts),len(chunk),0,
                      base64.b85encode(padded).decode("ascii"))); aparts+=1

    # Keep each Python source safely below the TI editor's practical paste cap.
    groups=[]; current=[]; payload=0
    for unit in units:
        cost=len(unit[3])+80
        if current and payload+cost>12000:
            groups.append(current); current=[]; payload=0
        current.append(unit); payload+=cost
    if current: groups.append(current)

    common='''from ti_system import store_list,recall_list
ALPHABET="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz!#$%&()*+-;<=>?@^_`{|}~"
def decode(blob,length):
 out=[]
 for start in range(0,len(blob),5):
  value=0
  for ch in blob[start:start+5]: value=value*85+ALPHABET.index(ch)
  out.extend(((value>>24)&255,(value>>16)&255,(value>>8)&255,value&255))
 return out[:length]
def install(name,length,signed,blob):
 values=decode(blob,length)
 if signed:
  for j in range(len(values)):
   if values[j]>127: values[j]-=256
  pairs=[]
  for j in range(0,len(values),2):
   first=values[j]+128
   second=values[j+1]+128 if j+1<len(values) else 128
   pairs.append(first*256+second)
  values=pairs
 store_list(name,values)
'''
    data_sources=[]
    total_parts=len(groups)
    for part,group in enumerate(groups):
        name="tinydata" if part==0 else "tinydata"+str(part+1)
        header="# CalcGPT 3 model installer %d of %d. Run in order.\nMODEL_ID=%d\n"%(part+1,total_parts,model_id)
        prelude=""
        if part==0:
            prelude='''try:
 installed=recall_list("tdinfo")
except Exception:
 installed=[]
if len(installed)>7 and int(installed[0])==13 and int(installed[7])==MODEL_ID:
 pasted=input("Paste for CalcGPT, then press Enter: ")
 store_list("tdpaste",[ord(ch) for ch in pasted[:120]])
 print("Paste saved. Run CalcGPT.")
 raise SystemExit
'''
        rows=[]
        for unit_name,unit_length,signed,encoded in group:
            rows.append("install(%r,%d,%d,%r)"%(unit_name,unit_length,signed,encoded))
        tail='\nstore_list("tds%d",[MODEL_ID])\n'%(part+1)
        if part+1<total_parts:
            tail+='print("Part %d of %d installed. Run %s next.")\n'%(part+1,total_parts,"tinydata"+str(part+2))
        else:
            checks='''\nfor stage in range(1,%d):
 try: marker=recall_list("tds"+str(stage))
 except Exception: marker=[]
 if not marker or int(marker[0])!=MODEL_ID:
  print("Missing model part",stage); raise SystemExit
'''%total_parts
            tail+=checks
            tail+='store_list("tdlens",%r)\n'%list(lengths)
            tail+='store_list("tdscale",%r)\n'%list(scales)
            tail+='store_list("tdqp",%r)\n'%qparts
            tail+='store_list("tdinfo",[13,%d,%d,%d,%d,%d,%d,MODEL_ID])\n'%(cfg["embedding"],cfg["hidden"],saved["epochs"],len(vocab),vparts,aparts)
            tail+='print("CalcGPT 3 model installed. Run tinylm.")\n'
        data_sources.append((name,header+common+prelude+"\n".join(rows)+tail))
    replacements = {
        "@E@": str(cfg["embedding"]), "@H@": str(cfg["hidden"]),
        "@INTENT_RAW@": repr(tuple(intent_raw)),
        "@EMOTION_RAW@": repr(tuple(emotion_raw)),
    }
    for old, new in replacements.items(): template = template.replace(old, new)
    folder = ROOT / "calculator"
    folder.mkdir(exist_ok=True)
    for old in folder.glob("tinydata*.py"):
        old.unlink()
    main_out = folder / "tinylm.py"
    main_out.write_text(template)
    data_outputs=[]
    for name,source in data_sources:
        output=folder/(name+".py"); output.write_text(source)
        compile(source,str(output),"exec"); data_outputs.append(output)
    compile(template, str(main_out), "exec")
    return tuple([main_out]+data_outputs)


if __name__ == "__main__":
    print(export(ROOT/"checkpoints"/"calcgpt3.pt"))
